<?php defined( 'ABSPATH' ) or die(  );?>
<div class="rsssl-wizard-wrap" id="rsssl-wizard">
	<?php //this header is a placeholder to ensure notices do not end up in the middle of our code ?>
    <h1 class="rsssl-notice-hook-element"></h1>
	<div id="rsssl-{page}">
		<div id="rsssl-content-area">
			{content}
		</div>
	</div>
</div>
