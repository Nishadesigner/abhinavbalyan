<?php
defined( 'ABSPATH' ) or die();

/**
 * On hostgator, we don't have the cpanel api, so remove these steps.
 * This is managed in the config, in the hosts array
*/
