<div class="rsssl-item {class}">
	<div class="item-container">
        {form_open}
        <div class="rsssl-grid-item-header">
            <h3>{title}</h3>
            {header}
        </div>
		<div class="rsssl-grid-item-content">
			{content}
		</div>
		<div class="rsssl-grid-item-footer">
			{footer}
		</div>
        {form_close}
	</div>
</div>
